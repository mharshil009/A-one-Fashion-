﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Admin_Product : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Product_priceTextBox_TextChanged(object sender, EventArgs e)
    {

    }
    protected void InsertButton_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True;User Instance=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT MAX(Product_id) From Product";
        cmd.Connection = cn;

        int i;
        i = (int)cmd.ExecuteScalar();
        i += 1;

        TextBox tx;
        tx = (TextBox)FormView1.FindControl("Product_idTextBox");
        tx.Text = Convert.ToString(i);
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList dr;
        TextBox tx;
        dr = (DropDownList)FormView1.FindControl("DropDownList1");
        tx = (TextBox)FormView1.FindControl("Color_idTextBox");
        tx.Text = dr.SelectedValue;
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList dr;
        TextBox tx;
        dr = (DropDownList)FormView1.FindControl("DropDownList2");
        tx = (TextBox)FormView1.FindControl("Size_idTextBox");
        tx.Text = dr.SelectedValue;
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList dr;
        TextBox tx;
        dr = (DropDownList)FormView1.FindControl("DropDownList3");
        tx = (TextBox)FormView1.FindControl("Category_idTextBox");
        tx.Text = dr.SelectedValue;
    }
    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList dr;
        TextBox tx;
        dr = (DropDownList)FormView1.FindControl("DropDownList4");
        tx = (TextBox)FormView1.FindControl("Offer_idTextBox");
        tx.Text = dr.SelectedValue;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        FileUpload fileupload1 = (FileUpload)FormView1.FindControl("FileUpload1");
        TextBox tx;
        int size = fileupload1.PostedFile.ContentLength;
        if (fileupload1.HasFile)
        {
            if (fileupload1.PostedFile.ContentType == "image/jpeg" || fileupload1.PostedFile.ContentType == "image/bmp" || fileupload1.PostedFile.ContentType == "image/png")
            {
                if (size < 1000000)
                {
                    fileupload1.SaveAs(Server.MapPath("~/App_Themes/Theme1/images/" + fileupload1.FileName));
                }
            }
        }
        tx = (TextBox)FormView1.FindControl("Product_imageTextBox");
        fileupload1 = (FileUpload)FormView1.FindControl("FileUpload1");
        // tx.Text = "~/App_Themes/Theme1/images/" + Path.GetFileName(fileupload1.FileName);
        tx.Text = fileupload1.FileName;
    }
}