﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Admin_Area : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
 
    protected void InsertButton_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True;User Instance=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT MAX(Area_id) From Area";
        cmd.Connection = cn;

        int i;
        i = (int)cmd.ExecuteScalar();
        i += 1;

        TextBox tx;
        tx = (TextBox)FormView1.FindControl("Area_idTextBox");
        tx.Text = Convert.ToString(i);
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList dr;
        TextBox tx;
        dr = (DropDownList)FormView1.FindControl("DropDownList1");
        tx = (TextBox)FormView1.FindControl("City_idTextBox");
        tx.Text = dr.SelectedValue;
    }
    protected void InsertButton_Click1(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True;User Instance=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT MAX(Area_id) From Area";
        cmd.Connection = cn;

        int i;
        i = (int)cmd.ExecuteScalar();
        i += 1;

        TextBox tx;
        tx = (TextBox)FormView1.FindControl("Area_idTextBox");
        tx.Text = Convert.ToString(i);
    }
    protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        DropDownList dr;
        TextBox tx;
        dr = (DropDownList)FormView1.FindControl("DropDownList1");
        tx = (TextBox)FormView1.FindControl("City_idTextBox");
        tx.Text = dr.SelectedValue;
    }
}