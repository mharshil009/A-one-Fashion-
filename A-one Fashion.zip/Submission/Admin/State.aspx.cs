﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Admin_State : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void InsertButton_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True;User Instance=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT MAX(State_id) From State";
        cmd.Connection = cn;

        int i;
        i = (int)cmd.ExecuteScalar();
        i += 1;

        TextBox tx;
        tx = (TextBox)FormView1.FindControl("State_idTextBox");
        tx.Text = Convert.ToString(i);
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList dr;
        TextBox tx;
        dr = (DropDownList)FormView1.FindControl("DropDownList1");
        tx = (TextBox)FormView1.FindControl("Country_idTextBox");
        tx.Text = dr.SelectedValue;
    }
}