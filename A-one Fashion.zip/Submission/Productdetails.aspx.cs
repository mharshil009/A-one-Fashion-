﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

public partial class Productdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (User.Identity.IsAuthenticated)
        {
          // string str1 = Membership.GetUser().UserName;
           //Label5.Text = str1;
           Label5.Text = User.Identity.Name;
        }
        else
        {
            Label5.Text ="Harshil" ;
        }
        /*MembershipUser user = Membership.GetUser(Label5.Text, false);
        if (Label5.Text != null)
        {
            Label5.Text = user.UserName;
        }
        else 
        {
            Label5.Text = "please first login";
        }*/
        DataTable dt = new DataTable();
        dt = (DataTable)Session["buyitems"];
        if (dt != null)
        {
            Label1.Text = dt.Rows.Count.ToString();

        }
        else
        {
            Label1.Text = "0";
        }

        //if (!IsPostBack)
        //{
          //  BindRatings();
        //}
    }
 

    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        //Response.Redirect(" Addtocart.aspx?id" + e.CommandArgument.ToString());
    }
   
   
  
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        double Price = double.Parse(((Label)DataList1.Controls[0].FindControl("Product_priceLabel")).Text);
        string ProductName = ((Label)DataList1.Controls[0].FindControl("Product_priceLabel")).Text;
        string PictureURL = ((Label)DataList1.Controls[0].FindControl("Label2")).Text;
        int ProductID = int.Parse(Request.QueryString["pid"]);
        if (Profile.Cart == null)
        {
            Profile.Cart = new Wrox.Commerce.ShoppingCart();
        }
        Profile.Cart.Insert(ProductID, Price, 1, ProductName, PictureURL);
        Server.Transfer("~/SecureOrder/ShoppingCartPage.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = null;
        SqlCommand cmd;
        cn = new SqlConnection();
        cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True;User Instance=True";
        cn.Open();
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "INSERT INTO Rating (Product_id, User_master_name,Rating )" + " VALUES (@Product_id, @User_master_name, @Rating )";

       
        // int Customize_order_id = i;
        //cmd.Parameters["@Customize_order_id"].Value = Customize_order_id;
        TextBox1.Text = Request.QueryString["pid"];
        cmd.Parameters.AddWithValue("@Product_id", TextBox1.Text);
       // String str = Membership.GetUser().UserName;
       // Label5.Text = str;
        cmd.Parameters.AddWithValue("@Rating", SqlDbType.Int).Value = Rating1.CurrentRating;
        cmd.Parameters.AddWithValue("@User_master_name", Label5.Text);

        cmd.ExecuteNonQuery();

        int Total = 0;

        SqlCommand cmd2 = new SqlCommand("SELECT * FROM Rating", cn);

        SqlDataAdapter da = new SqlDataAdapter(cmd2);

        DataTable dt = new DataTable();

        da.Fill(dt);

        if (dt.Rows.Count > 0)
        {

            for (int j = 0; j < dt.Rows.Count; j++)
            {

                Total += Convert.ToInt32(dt.Rows[j][0].ToString());

            }


            int Average = Total / (dt.Rows.Count);

            Rating1.CurrentRating = Average;
        }
        //BindRatings();

    }
    //public void BindRatings()
    //{

        
    //}
}