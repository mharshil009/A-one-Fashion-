﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class SignUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void CreateUserWizard1_CreatedUser(object sender, EventArgs e)
    {
       // Response.Redirect("Login.aspx");
    }
    protected void CreateUserWizard1_ContinueButtonClick(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
    protected void CreateUserWizard1_CreatingUser(object sender, LoginCancelEventArgs e)
    {
      /*  Profile.Uid = TextBox1.Text;
        Profile.Fname = TextBox2.Text;
        Profile.Lname = TextBox3.Text;
        Profile.Add1 = TextBox4.Text;
        Profile.Add2 = TextBox5.Text;
        Profile.Country = DropDownList1.Text;
        Profile.State = DropDownList2.Text;
        Profile.City = DropDownList3.Text;
        Profile.Cno = TextBox10.Text;*/
    }
    protected void CreateUserWizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
    {
      
       Profile.Fname = TextBox1.Text;
       Profile.Lname = TextBox2.Text;
       Profile.Add = TextBox3.Text;

       Profile.Country = DropDownList1.Text;
        Profile.State = DropDownList2.Text;
        Profile.City = DropDownList3.Text;
        Profile.Area = DropDownList4.Text;
        Profile.Pcode = TextBox4.Text;
        Profile.Cno = TextBox5.Text;

      /*  SqlConnection cn = new SqlConnection();
        cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True;User Instance=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT MAX(User_master_id) From User_master";
        cmd.Connection = cn;

        int i;
        i = (int)cmd.ExecuteScalar();
        i += 1;

        TextBox tx;
        tx = (TextBox)FormView1.FindControl("User_master_idTextBox");
        tx.Text = Convert.ToString(i);*/
    }
    protected void InsertButton_Click(object sender, EventArgs e)
    {
      /*  SqlConnection cn = new SqlConnection();
        cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True;User Instance=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT MAX(User_master_id) From User_master";
        cmd.Connection = cn;

        int i;
        i = (int)cmd.ExecuteScalar();
        i += 1;

        TextBox tx;
        tx = (TextBox)FormView1.FindControl("User_master_idTextBox");
        tx.Text = Convert.ToString(i);*/
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void SqlDataSource9_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
}