﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

public partial class Customize_order_Customize_order_details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
            TextBox3.Focus();
    }
    protected void chkUseProfileAddress_CheckedChanged(object sender, EventArgs e)
    {
        if (chkUseProfileAddress.Checked && TextBox11.Text.Trim() == "")
        {
            TextBox11.Text = Profile.Fname;
            TextBox12.Text = Profile.Lname;
            TextBox13.Text = Profile.Add;
            TextBox14.Text = Profile.Country;
            TextBox15.Text = Profile.State;
            TextBox16.Text = Profile.City;
            TextBox17.Text = Profile.Area;
            TextBox18.Text = Profile.Pcode;
            TextBox10.Text = Profile.Cno;


        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = null;
        SqlCommand cmd;
        cn = new SqlConnection();
        cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True;User Instance=True";
        cn.Open();
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText="INSERT INTO Customize_order (Customize_order_id, Customize_order_date, Description, Print_image, Qty, Size, Approve, Delivery_address, Area_id, Product_id, User_name )" + " VALUES (@Customize_order_id, @Customize_order_date, @Description, @Print_image, @Qty, @Size, @Approve, @Delivery_address, @Area_id, @Product_id, @User_name )";

        SqlCommand cmd1 = new SqlCommand();
        cmd1.CommandText = "SELECT MAX(Customize_Order_id) From Customize_order";
        cmd1.Connection = cn;

        int i;
        i = (int)cmd1.ExecuteScalar();
        i += 1;
        TextBox1.Text = Convert.ToString(i);
       // int Customize_order_id = i;
        //cmd.Parameters["@Customize_order_id"].Value = Customize_order_id;
        cmd.Parameters.AddWithValue("@Customize_order_id", TextBox1.Text);

        TextBox2.Text = DateTime.Now.ToString("dd/MM/yyyy");
        cmd.Parameters.AddWithValue("@Customize_order_date", TextBox2.Text);
        cmd.Parameters.AddWithValue("@Description", TextBox3.Text);


        int size = FileUpload1.PostedFile.ContentLength;
        if (FileUpload1.HasFile)
        {
            if (FileUpload1.PostedFile.ContentType == "image/jpeg" || FileUpload1.PostedFile.ContentType == "image/bmp" || FileUpload1.PostedFile.ContentType == "image/png")
            {
                if (size < 1000000)
                {
                    FileUpload1.SaveAs(Server.MapPath("~/App_Themes/Theme1/images/" + FileUpload1.FileName));
                }
            }
        }
        cmd.Parameters.AddWithValue("@Print_image", FileUpload1.FileName);
        cmd.Parameters.AddWithValue("@Qty", DropDownList1.SelectedItem.Value);
        cmd.Parameters.AddWithValue("@Size", DropDownList2.SelectedItem.Value);
        TextBox4.Text = "False";
        cmd.Parameters.AddWithValue("@Approve", TextBox4.Text);

        TextBox5.Text = TextBox13.Text;
        cmd.Parameters.AddWithValue("@Delivery_address", TextBox5.Text);

        TextBox6.Text = TextBox17.Text;
        cmd.Parameters.AddWithValue("@Area_id", TextBox6.Text);

        TextBox7.Text = Request.QueryString["pid"];
        cmd.Parameters.AddWithValue("@Product_id", TextBox7.Text);

        String str = Membership.GetUser().UserName;
        TextBox8.Text = str;
        cmd.Parameters.AddWithValue("@User_name", TextBox8.Text);

        cmd.ExecuteNonQuery();


        Label24.Text = "Order place successfully:";










    }
}