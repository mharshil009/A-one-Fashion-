﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Wrox.Commerce;

public partial class ShoppingCart : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Profile.Cart == null)
        {
            Profile.Cart = new Wrox.Commerce.ShoppingCart();
        }
        if (!Page.IsPostBack)
        {
            BindGrid();
        }
        if (Profile.Cart.Items == null)
        {
            Label1.Visible = false;
        }
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        BindGrid();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdatedEventArgs e)
    {
      /*  TextBox QuantityTextBox = (TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0];
        int Quantity = Convert.ToInt32(QuantityTextBox.Text); 
        if (Quantity == 0) 
        {
            Profile.Cart.Items.RemoveAt(e.RowIndex);
        } 
        else
        {
            Profile.Cart.Items[e.RowIndex].Quantity = Quantity;
        }
        GridView1.EditIndex = -1; BindGrid();
        */
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1; BindGrid();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
    }
    private void BindGrid()
    {
        GridView1.DataSource = Profile.Cart.Items;
        DataBind();
        Label1.Text = String.Format("Total:{0,19:C}", Profile.Cart.Total);
    }
    protected void GridView1_RowDeleting1(object sender, GridViewDeleteEventArgs e)
    {
        Profile.Cart.Items.RemoveAt(e.RowIndex);
        BindGrid();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowUpdating1(object sender, GridViewUpdateEventArgs e)
    {
        TextBox QuantityTextBox = (TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0];
        int Quantity = Convert.ToInt32(QuantityTextBox.Text);
        
        if (Quantity == 0)
        {
            Profile.Cart.Items.RemoveAt(e.RowIndex);
        }
        else
        {
            Profile.Cart.Items[e.RowIndex].Quantity = Quantity;
        }
        GridView1.EditIndex = -1; BindGrid();
    }
    protected void GridView1_RowEditing1(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        BindGrid();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

    }
}
