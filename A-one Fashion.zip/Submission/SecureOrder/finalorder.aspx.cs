﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Wrox.Commerce;
using System.Web.Security;
using System.Configuration;



public partial class SecureOrder_finalorder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Profile.Cart == null)
            {
                NoCartlabel.Visible = true;
                Wizard1.Visible = false;
            }
            if (User.Identity.IsAuthenticated)
            {
                 Wizard1.ActiveStepIndex = 1;
            }
            else
            {
                 Wizard1.ActiveStepIndex = 0;
            }

          }

    }
  
    protected void chkUseProfileAddress_CheckedChanged(object sender, EventArgs e)
    {
        if (chkUseProfileAddress.Checked && TextBox2.Text.Trim() == "")
        {
            TextBox2.Text = Profile.Fname;
            TextBox3.Text = Profile.Lname;
            TextBox4.Text = Profile.Add;
            TextBox5.Text = Profile.Country;
            TextBox6.Text = Profile.State;
            TextBox7.Text = Profile.City;
            TextBox8.Text = Profile.Area;
            TextBox9.Text = Profile.Pcode;
            TextBox10.Text = Profile.Cno;
            

        }
    }
    protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
    {
        SqlConnection cn =null;
          SqlCommand cmd;
          try
          {

              cn = new SqlConnection();
              cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True;User Instance=True";
           //cn = new SqlConnection(ConfigurationManager.ConnectionStrings["WroxUnited"].ConnectionString);
              cn.Open();
              cmd = new SqlCommand();
              cmd.Connection = cn;
              cmd.CommandText = "INSERT INTO [Order] (Order_id, Order_date, Order_Status, Order_delivery_address, Order_total_amt, Area_id, User_name )" + " VALUES (@Order_id, @Order_date, @Order_Status, @Order_delivery_address, @Order_total_amt, @Area_id, @User_name)";


              cmd.Parameters.Add("@Order_id", SqlDbType.Int);
              cmd.Parameters.Add("@Order_date", SqlDbType.DateTime);
              cmd.Parameters.Add("@Order_status", SqlDbType.VarChar, 45);
              cmd.Parameters.Add("@Order_delivery_address", SqlDbType.NVarChar, 100);
              cmd.Parameters.Add("@Order_total_amt", SqlDbType.Int);
              cmd.Parameters.Add("@Area_id", SqlDbType.Int);
              cmd.Parameters.Add("@User_name", SqlDbType.VarChar, 20);

              SqlCommand cmd1 = new SqlCommand();
              cmd1.CommandText = "SELECT MAX(Order_id) From [Order]";
              cmd1.Connection = cn;

              int i;
              i = (int)cmd1.ExecuteScalar();
              i += 1;

              int Order_id = i;

              cmd.Parameters["@Order_id"].Value = Order_id;
              cmd.Parameters["@Order_date"].Value = DateTime.Now;
              cmd.Parameters["@Order_status"].Value = "Confirm";
              cmd.Parameters["@Order_delivery_address"].Value = ((TextBox)Wizard1.FindControl("TextBox4")).Text; 
              cmd.Parameters["@Order_total_amt"].Value = Profile.Cart.Total;
              cmd.Parameters["@Area_id"].Value = ((TextBox)Wizard1.FindControl("TextBox8")).Text;
              
              String str = Membership.GetUser().UserName;
              cmd.Parameters["@User_name"].Value = str;
              cmd.ExecuteNonQuery();
              cmd.CommandText = "INSERT INTO Order_details(Order_id, Product_id, Qty, Price) " + "VALUES (@Order_id, @Product_id, @Qty, @Price)";

              cmd.Parameters.Clear();
              cmd.Parameters.Add("@Order_id", SqlDbType.Int);
              cmd.Parameters.Add("@Product_id", SqlDbType.Int);
              cmd.Parameters.Add("@Qty", SqlDbType.Int);
              cmd.Parameters.Add("@Price", SqlDbType.Int);


              cmd.Parameters["@Order_id"].Value = Order_id;
              foreach (CartItem item in Profile.Cart.Items)
              {
                  cmd.Parameters["@Product_id"].Value = item.ProductID;
                  cmd.Parameters["@Qty"].Value = item.Quantity;
                  cmd.Parameters["@Price"].Value = item.Price;
                  cmd.ExecuteNonQuery();

              }


          }
          catch (SqlException SqlEx)
          {
             // throw new Exception("An error occurred while creating the order", SqlEx);
          }
          finally
          {
              if (cn != null)
              {
                  cn.Close();
              }
          }
          Profile.Cart.Items.Clear();
          Label11.Text = "Your order is confirmed:";

    }

    protected void Wizard1_NextButtonClick(object sender, WizardNavigationEventArgs e)
    {
         if (e.CurrentStepIndex == 0)
            {
                System.Web.UI.WebControls.Login l = (System.Web.UI.WebControls.Login)Wizard1.FindControl("Login1");
                if (Membership.ValidateUser(l.UserName, l.Password))
                {
                    FormsAuthentication.SetAuthCookie(l.UserName, l.RememberMeSet); 
                    e.Cancel = false;
                }
                else
                {
                    {
                        l.InstructionText = "Your login attempt was not successful. Please try again."; 
                        l.InstructionTextStyle.ForeColor = System.Drawing.Color.Red;
                        e.Cancel = true;
                    }
                }
            }
                else 
                {
                    if (!User.Identity.IsAuthenticated) 
                    {
                        e.Cancel = true; 
                        Wizard1.ActiveStepIndex = 0;
                    }
                }

            
        

        }
        protected void Wizard1_ActiveStepChanged(object sender, EventArgs e)
        {
            if (!User.Identity.IsAuthenticated) 
                Wizard1.ActiveStepIndex = 0;

        }
        protected void LoginView1_ViewChanged(object sender, EventArgs e)
        {

        }
}

